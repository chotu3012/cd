
int main()
{
  int a;
  printf("hello");

}