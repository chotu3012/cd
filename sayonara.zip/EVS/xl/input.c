//hey hi
int main()
{
  int a;
  printf("hello");
/* dfjewkfj k
fdfrfre */
}