#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>

int FIRST(char* res,char c,char p[20][20]);
int main()
{
	int n,i,exit=0;
	char p[20][20],c,res[10];
	printf("enter number of productions:");
	scanf("%d",&n);
	printf("enter the productions:");
	for(i=0;i<n;i++)
	{
		scanf("%s",p[i]);
	}
	while(exit==0)
	{
		printf("enter first of:");
		scanf(" %c",&c);
		int count=FIRST(res,c,p);
		printf("first(%c)={",c);
		for(i=0;i<count;i++)
		{
			printf("%c",res[i]);
			
		}
		printf("}");
		printf("to continue enter 0 to exit enter 1");
		scanf("%d",&exit);
		
	}
		
}
int FIRST(char* res,char c,char p[20][20])
{
	int i,j=0,k,count=0;
	char sub[10];
	for(i=0;p[i][0]!='\0';i++)
	{
		if(p[i][0]==c)
		{
			if(isupper(p[i][2]))
			{
				int c1=FIRST(sub,p[i][2],p);
				for(k=0;k<c1;k++)
				{
					if(sub[k]=='$')
					{
						sub[k]=p[i][3];
					}
					res[j++]=sub[k];
					count++;
				}
			}
			else{
				res[j++]=p[i][2];
				count++;
			}
		}
	}
	return count;
}
/*
     Enter the number of productions 8
ENter the production rules
E=TR
R=+TR
R=$
T=FY
Y=*FY
Y=$
F=(E)
F=i
Find the first of :E
first(E)={(i}If you want to continue enter 0, to exit enter 1 0
Find the first of :R
first(R)={+$}If you want to continue enter 0, to exit enter 1 0
Find the first of :T
first(T)={(i}If you want to continue enter 0, to exit enter 1 0
Find the first of :Y
first(Y)={*$}If you want to continue enter 0, to exit enter 1 0
Find the first of :F
first(F)={(i}If you want to continue enter 0, to exit enter 1



*/

