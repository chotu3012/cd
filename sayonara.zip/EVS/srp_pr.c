#include <stdio.h>
#include <stdlib.h>
#include <String.h>
struct productions{
    char left[10];
    char right[10];
};
void main()
{
int n,i;
printf("Enter the number of productions ");
scanf("%d",&n);
struct productions p[n];
char s[10],*token1,*token2,*sub,ch[2];
printf("Enter the productions in the form of X->x ");
for(i=0;i<n;i++)
{
    scanf("%s",s);
    token1=strtok(s,"->");
    token2=strtok(NULL,"->");
    strcpy(p[i].left,token1);
    strcpy(p[i].right,token2);
}
printf("Enter the input string ");
char input[20],stack[20];
stack[0]='\0';
scanf("%s",input);
int j=0,top=0,k,l;
i=0;
while(1)
{
    if(j<strlen(input))
    {
    ch[0]=input[j++];
    ch[1]='\0';
    strcat(stack,ch);
    printf("%s\t",stack);
    for(i=j;i<strlen(input);i++)
    printf("%c",input[i]);
    printf("\tshift %c",ch[0]);
    printf("\n");
    }
    for(k=0;k<n;k++)
    {
        sub=strstr(stack,p[k].right);
        if(sub!=NULL)
        {
            l=strlen(stack)-strlen(sub);
            stack[l]='\0';
            strcat(stack,p[k].left);
            printf("%s\t",stack);
            for(i=j;i<strlen(input);i++)
            printf("%c",input[i]);
            printf("\tReduce %s->%s\n",p[k].right,p[k].left);
            k=-1;
        }
    }
     if (strcmp(stack, p[0].left) == 0 && j == strlen(input))
        {
            printf("\nAccepted");
            break;
        }
    if(j==strlen(input))
     {
        printf("\n Notaccepted");
        break;
     }
}
}
/*
Enter the number of productions 3
Enter the productions in the form of X->x
E->E+E
E->E*E
E->i
Enter the input string i+i*i
i       +i*i    shift i
E       +i*i    Reduce i->E
E+      i*i     shift +
E+i     *i      shift i
E+E     *i      Reduce i->E
E       *i      Reduce E+E->E
E*      i       shift *
E*i             shift i
E*E             Reduce i->E
E               Reduce E*E->E

Accepted
*/
