#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
int n,m=0,p,i=0,j=0;
char a[10][10],res[10];
void FOLLOW(char c);
void FIRST(char c);
int main()
{
	int i,z;
	char c,ch;
	printf("enter number of productions:");
	scanf("%d",&n);
	printf("enter the productions:");
	for(i=0;i<n;i++)
	scanf("%s%c",a[i],&ch);
	do{
		m=0;
		printf("enter follow of:");
		scanf("%c",&c);
		FOLLOW(c);
		printf("follow(%c)={",c);
		for(i=0;i<m;i++)
		printf("%c",res[i]);
		printf("}\n");
		printf("enter 1 to continue and 0 to exit");
		scanf("%d%c",&z,&ch);
	}
	while(z==1);
}
void FOLLOW(char c)
{
	if(a[0][0]==c) res[m++]='$';
	for(i=0;i<n;i++)
	{
		for(j=2;j<strlen(a[i]);j++)
		{
			if(a[i][j]==c)
			{
			
			if(a[i][j+1]!='\0') 
			  FIRST(a[i][j+1]);
			if(a[i][j+1]=='\0' && c!=a[i][0]) 
			  FOLLOW(a[i][0]); 
	      	}
		}
	}
}
void FIRST(char c)
{
	int k;
	if(!(isupper(c)))
	  res[m++]=c;
	for(k=0;k<n;k++)
	{
		if(a[k][0]==c)
		{
			if(a[k][2]=='$') 
			  FOLLOW(a[i][0]);
			else if(islower(a[k][2])) 
			  res[m++]=a[k][2];
			else 
			  FIRST(a[k][2]);
		}
	}
}


/*
enter number of productions:8
enter the productions:
E=TR
R=+TR
R=$
T=FY
Y=*FY
Y=$
F=(E)
F=i
enter follow of:E
follow(E)={$)}
enter 1 to continue and 0 to exit1
enter follow of:R
follow(R)={$)}
enter 1 to continue and 0 to exit1
enter follow of:T
follow(T)={+$)}
enter 1 to continue and 0 to exit1
enter follow of:Y
follow(Y)={+$)}
enter 1 to continue and 0 to exit1
enter follow of:F
follow(F)={*+$)}
enter 1 to continue and 0 to exit
*/







